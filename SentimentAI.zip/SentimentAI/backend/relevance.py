import re


def analyze_relevance(answer, keywords):

    # Convert answer to lowercase
    answer_lower = answer.lower()


    # Find words in the answer
    words = re.findall(r"\b\w+\b", answer_lower)


    # Remove duplicate words
    answer_words = set(words)


    # Count matching keywords
    matched_keywords = []

    for keyword in keywords:

        if keyword.lower() in answer_words:

            matched_keywords.append(keyword)


    # Calculate keyword score

    if len(keywords) == 0:

        keyword_score = 0

    else:

        keyword_score = (
            len(matched_keywords)
            / len(keywords)
        ) * 100


    # Answer length score

    word_count = len(words)


    if word_count < 10:

        length_score = 40

    elif word_count < 25:

        length_score = 70

    elif word_count < 50:

        length_score = 90

    else:

        length_score = 100


    # Final relevance score

    relevance_score = (
        keyword_score * 0.7
        +
        length_score * 0.3
    )


    return {

        "relevance_score":
            round(relevance_score, 2),

        "keyword_score":
            round(keyword_score, 2),

        "length_score":
            round(length_score, 2),

        "word_count":
            word_count,

        "matched_keywords":
            matched_keywords

    }