from flask import Flask, send_from_directory, request, jsonify
import os

from sentiment import analyze_sentiment
from relevance import analyze_relevance


# ==========================================
# Flask Configuration
# ==========================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, "..", "frontend")

app = Flask(__name__)


# ==========================================
# Frontend Pages
# ==========================================

@app.route("/")
def home():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.route("/<path:filename>")
def frontend_files(filename):
    return send_from_directory(FRONTEND_DIR, filename)


# ==========================================
# Test API
# ==========================================

@app.route("/api/test")
def test():

    return jsonify({
        "status": "success",
        "message": "SentimentAI backend is working!"
    })


# ==========================================
# Sentiment Analysis API
# ==========================================

@app.route("/api/analyze-sentiment", methods=["POST"])
def analyze_sentiment_api():

    data = request.get_json()

    text = data.get("text", "").strip()

    if not text:

        return jsonify({
            "error": "No text provided"
        }), 400

    result = analyze_sentiment(text)

    return jsonify(result)


# ==========================================
# Relevance Analysis API
# ==========================================

@app.route("/api/analyze-relevance", methods=["POST"])
def analyze_relevance_api():

    data = request.get_json()

    answer = data.get("answer", "").strip()

    keywords = data.get("keywords", [])

    if not answer:

        return jsonify({
            "error": "No answer provided"
        }), 400

    result = analyze_relevance(
        answer,
        keywords
    )

    return jsonify(result)


# ==========================================
# Start Server
# ==========================================

if __name__ == "__main__":

    app.run(
        debug=True,
        host="127.0.0.1",
        port=5000
    )