from sentiment import analyze_sentiment


text = "I don't understand python."

result = analyze_sentiment(text)

print(result)