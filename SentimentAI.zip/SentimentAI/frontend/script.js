const startButton = document.getElementById("startBtn");

startButton.addEventListener("click", function () {

    window.location.href = "interview.html";

});