// ===============================
// SentimentAI Interview System
// ===============================


// ===============================
// HR Questions
// ===============================

const hrQuestions = [

    {
        question: "Tell me about yourself.",
        keywords: [
            "education",
            "skills",
            "experience",
            "project",
            "career"
        ]
    },

    {
        question: "What are your strengths and weaknesses?",
        keywords: [
            "strength",
            "weakness",
            "skill",
            "improve",
            "learning"
        ]
    },

    {
        question: "Why should we hire you?",
        keywords: [
            "skills",
            "experience",
            "knowledge",
            "team",
            "contribute"
        ]
    },

    {
        question: "Where do you see yourself in five years?",
        keywords: [
            "career",
            "growth",
            "experience",
            "skills",
            "leadership"
        ]
    },

    {
        question: "How do you handle pressure or difficult situations?",
        keywords: [
            "pressure",
            "problem",
            "solution",
            "calm",
            "team"
        ]
    }

];


// ===============================
// Technical Questions
// ===============================

const technicalQuestions = [

    {
        question: "What is Object-Oriented Programming?",
        keywords: [
            "object",
            "class",
            "inheritance",
            "encapsulation",
            "polymorphism"
        ]
    },

    {
        question: "What is normalization in DBMS?",
        keywords: [
            "database",
            "redundancy",
            "normalization",
            "table",
            "data"
        ]
    },

    {
        question: "What is the difference between SQL and NoSQL?",
        keywords: [
            "sql",
            "nosql",
            "database",
            "relational",
            "document"
        ]
    },

    {
        question: "What is cloud computing?",
        keywords: [
            "cloud",
            "internet",
            "server",
            "storage",
            "computing"
        ]
    },

    {
        question: "Explain the difference between HTTP and HTTPS.",
        keywords: [
            "http",
            "https",
            "security",
            "encryption",
            "ssl",
            "tls"
        ]
    }

];


// Variables

let selectedType = "";

let questions = [];

let currentQuestion = 0;

let answers = [];


// Start Interview

function startInterview(type) {

    selectedType = type;

    if (type === "HR") {

        questions = hrQuestions;

    } else {

        questions = technicalQuestions;

    }


    currentQuestion = 0;

    answers = [];


    // Hide type selection

    document
        .getElementById("typeSelection")
        .classList.add("hidden");


    // Show interview

    document
        .getElementById("interviewSection")
        .classList.remove("hidden");


    document
        .getElementById("interviewType")
        .textContent = type;


    showQuestion();

}


// Show Question

function showQuestion() {

    const currentQuestionData =
        questions[currentQuestion];


    document
        .getElementById("question")
        .textContent =
        currentQuestionData.question;


    document
        .getElementById("questionNumber")
        .textContent =
        `Question ${currentQuestion + 1} of ${questions.length}`;


    // Progress bar

    const progress =
        ((currentQuestion + 1) / questions.length) * 100;


    document
        .getElementById("progressBar")
        .style.width =
        progress + "%";


    // Clear answer box

    document
        .getElementById("answer")
        .value = "";


    // Last question

    if (currentQuestion === questions.length - 1) {

        document
            .getElementById("nextButton")
            .classList.add("hidden");


        document
            .getElementById("submitButton")
            .classList.remove("hidden");

    }

}


// Next Question

function nextQuestion() {

    const answer =
        document.getElementById("answer").value.trim();


    if (answer === "") {

        alert(
            "Please enter your answer before continuing."
        );

        return;

    }


    answers.push({

        question:
            questions[currentQuestion].question,

        keywords:
            questions[currentQuestion].keywords,

        answer: answer

    });


    currentQuestion++;

    showQuestion();

}


// Submit Interview

async function submitInterview() {

    const answer =
        document.getElementById("answer").value.trim();


    if (answer === "") {

        alert("Please enter your answer before submitting.");

        return;

    }


    // Store final answer
    answers.push({

        question:
            questions[currentQuestion].question,

        keywords:
            questions[currentQuestion].keywords,

        answer: answer

    });


    try {

        const analyzedAnswers = [];


        // Analyze every answer
        for (const item of answers) {

            // ==============================
            // Sentiment Analysis
            // ==============================

            const sentimentResponse = await fetch(
                "/api/analyze-sentiment",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        text: item.answer
                    })
                }
            );


            if (!sentimentResponse.ok) {

                throw new Error(
                    "Sentiment API failed"
                );

            }


            const sentiment =
                await sentimentResponse.json();


            // ==============================
            // Relevance Analysis
            // ==============================

            const relevanceResponse = await fetch(
                "/api/analyze-relevance",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({

                        answer: item.answer,

                        keywords: item.keywords

                    })
                }
            );


            if (!relevanceResponse.ok) {

                throw new Error(
                    "Relevance API failed"
                );

            }


            const relevance =
                await relevanceResponse.json();


            // ==============================
            // Store Analysis
            // ==============================

            analyzedAnswers.push({

                question: item.question,

                answer: item.answer,

                sentiment:
                    sentiment.sentiment,

                positive:
                    sentiment.positive,

                negative:
                    sentiment.negative,

                neutral:
                    sentiment.neutral,

                compound:
                    sentiment.compound,

                relevance_score:
                    relevance.relevance_score,

                keyword_score:
                    relevance.keyword_score,

                length_score:
                    relevance.length_score,

                word_count:
                    relevance.word_count,

                matched_keywords:
                    relevance.matched_keywords

            });

        }


        // ==============================
        // Calculate Overall Score
        // ==============================

        let totalRelevance = 0;

        let totalLength = 0;


        analyzedAnswers.forEach(item => {

            totalRelevance +=
                item.relevance_score;

            totalLength +=
                item.length_score;

        });


        const overallRelevance =
            totalRelevance /
            analyzedAnswers.length;


        const communicationScore =
            totalLength /
            analyzedAnswers.length;


        const overallScore =
            (overallRelevance * 0.8) +
            (communicationScore * 0.2);


        // ==============================
        // Final Interview Data
        // ==============================

        const interviewData = {

            type: selectedType,

            answers: analyzedAnswers,

            overallRelevance:
                Number(overallRelevance.toFixed(2)),

            communicationScore:
                Number(communicationScore.toFixed(2)),

            overallScore:
                Number(overallScore.toFixed(2)),

            date:
                new Date().toISOString()

        };


        // Save data
        localStorage.setItem(
            "sentimentAIInterview",
            JSON.stringify(interviewData)
        );


        // Open result page
        window.location.href =
            "results.html";


    } catch (error) {

        console.error(
            "Interview analysis error:",
            error
        );


        alert(
            "There was a problem analyzing your answers. Please try again."
        );

    }

}


// Go Home

function goHome() {

    window.location.href = "index.html";

}