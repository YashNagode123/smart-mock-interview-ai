// ========================================
// SentimentAI Results Page
// ========================================


const savedData =
    localStorage.getItem("sentimentAIInterview");


// Check if interview exists

if (!savedData) {

    alert(
        "No interview result found."
    );

    window.location.href =
        "index.html";

}


// Convert JSON to JavaScript object

const interviewData =
    JSON.parse(savedData);


// ========================================
// Display Summary
// ========================================

document.getElementById(
    "overallScore"
).textContent =
    Math.round(interviewData.overallScore);


document.getElementById(
    "relevanceScore"
).textContent =
    Math.round(interviewData.overallRelevance);


document.getElementById(
    "communicationScore"
).textContent =
    Math.round(interviewData.communicationScore);


document.getElementById(
    "interviewInfo"
).textContent =

    `${interviewData.type} Interview • ` +
    `${interviewData.answers.length} Questions`;



// ========================================
// Display Individual Answers
// ========================================

const answersContainer =
    document.getElementById(
        "answersContainer"
    );


interviewData.answers.forEach(
    (item, index) => {


        const answerCard =
            document.createElement("div");


        answerCard.className =
            "answer-card";


        answerCard.innerHTML = `

            <div class="answer-header">

                <h3>
                    Question ${index + 1}
                </h3>

                <span class="sentiment">
                    ${item.sentiment}
                </span>

            </div>


            <p class="question-text">
                ${item.question}
            </p>


            <div class="candidate-answer">

                <strong>
                    Your Answer
                </strong>

                <p>
                    ${item.answer}
                </p>

            </div>


            <div class="analysis-grid">


                <div>

                    <span>
                        Relevance
                    </span>

                    <strong>
                        ${Math.round(item.relevance_score)}%
                    </strong>

                </div>


                <div>

                    <span>
                        Keyword Match
                    </span>

                    <strong>
                        ${Math.round(item.keyword_score)}%
                    </strong>

                </div>


                <div>

                    <span>
                        Answer Length
                    </span>

                    <strong>
                        ${item.word_count} words
                    </strong>

                </div>


                <div>

                    <span>
                        Sentiment
                    </span>

                    <strong>
                        ${item.sentiment}
                    </strong>

                </div>


            </div>


            <div class="matched-keywords">

                <strong>
                    Matched Keywords:
                </strong>

                ${
                    item.matched_keywords.length > 0
                    ?
                    item.matched_keywords.join(", ")
                    :
                    "No expected keywords detected"
                }

            </div>

        `;


        answersContainer.appendChild(
            answerCard
        );

    }
);



// ========================================
// Buttons
// ========================================

function startNewInterview() {

    localStorage.removeItem(
        "sentimentAIInterview"
    );

    window.location.href =
        "interview.html";

}


function goHome() {

    window.location.href =
        "index.html";

}